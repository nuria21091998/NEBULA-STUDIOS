/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

/**
 *
 * @author Nando
 */
import java.util.ArrayList;
 
public class GestorNotificaciones {
    private ArrayList<Notificacion> colaNotificaciones;
    
    public GestorNotificaciones() {
        this.colaNotificaciones = new ArrayList<>();
    }
    
    public void notificarOfertaWishlist(Cliente cliente, Juego juego, Oferta oferta) {
        String fecha = obtenerFechaActual();
        Notificacion notif = new Notificacion(cliente, juego, fecha, "Oferta");
        colaNotificaciones.add(notif);
        notif.enviar();
    }
    
    public void notificarNuevoLanzamiento(ArrayList<Cliente> clientes, Juego juego) {
        String fecha = obtenerFechaActual();
        for (Cliente cliente : clientes) {
            if (cliente.isNotificacionesActivas()) {
                Notificacion notif = new Notificacion(cliente, juego, fecha, "Lanzamiento");
                colaNotificaciones.add(notif);
                notif.enviar();
            }
        }
    }
    
    public void notificarStockDisponible(Cliente cliente, Juego juego) {
        String fecha = obtenerFechaActual();
        Notificacion notif = new Notificacion(cliente, juego, fecha, "StockDisponible");
        colaNotificaciones.add(notif);
        notif.enviar();
    }
    
    public void enviarNotificacionesPendientes() {
        System.out.println("\n📬 Enviando notificaciones pendientes...");
        int contador = 0;
        for (Notificacion notif : colaNotificaciones) {
            if (!notif.isLeida()) {
                notif.enviar();
                contador++;
            }
        }
        System.out.println("✓ " + contador + " notificaciones enviadas\n");
    }
    
    public void limpiarNotificacionesLeidas() {
        ArrayList<Notificacion> noLeidas = new ArrayList<>();
        for (Notificacion notif : colaNotificaciones) {
            if (!notif.isLeida()) {
                noLeidas.add(notif);
            }
        }
        int eliminadas = colaNotificaciones.size() - noLeidas.size();
        colaNotificaciones = noLeidas;
        System.out.println("✓ " + eliminadas + " notificaciones leídas eliminadas");
    }
    
    public void mostrarNotificaciones() {
        System.out.println("\n===== NOTIFICACIONES =====");
        if (colaNotificaciones.isEmpty()) {
            System.out.println("No hay notificaciones");
        } else {
            for (int i = 0; i < colaNotificaciones.size(); i++) {
                System.out.println((i + 1) + ". " + colaNotificaciones.get(i));
            }
        }
        System.out.println("==========================\n");
    }
    
    private String obtenerFechaActual() {
        return "2024-03-20";
    }
    
    public ArrayList<Notificacion> getColaNotificaciones() {
        return colaNotificaciones;
    }
}
