/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

/**
 *
 * @author Nando
 */
import java.util.ArrayList;
 
public class Cliente {
    private String idCliente;
    private String nombre;
    private String apellidos;
    private String email;
    private double saldoCartera;
    private ArrayList<Juego> wishlist;
    private ArrayList<Compra> biblioteca;
    private boolean notificacionesActivas;
    private String generoFavorito;
    
    public Cliente(String idCliente, String nombre, String apellidos, String email) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.saldoCartera = 0.0;
        this.wishlist = new ArrayList<>();
        this.biblioteca = new ArrayList<>();
        this.notificacionesActivas = true;
        this.generoFavorito = "";
    }
    
    public void agregarAWishlist(Juego juego) {
        if (!wishlist.contains(juego)) {
            wishlist.add(juego);
            System.out.println("✓ " + juego.getTitulo() + " añadido a tu wishlist");
        } else {
            System.out.println("Este juego ya está en tu wishlist");
        }
    }
    
    public void eliminarDeWishlist(Juego juego) {
        if (wishlist.remove(juego)) {
            System.out.println("✓ " + juego.getTitulo() + " eliminado de tu wishlist");
        } else {
            System.out.println("Este juego no está en tu wishlist");
        }
    }
    
    public void recargarSaldo(double cantidad) {
        if (cantidad > 0) {
            saldoCartera += cantidad;
            System.out.println("✓ Saldo recargado. Nuevo saldo: " + saldoCartera + "€");
        }
    }
    
    public boolean tieneSaldoSuficiente(double precio) {
        return saldoCartera >= precio;
    }
    
    public void comprarJuego(Juego juego, double precio) {
        if (tieneSaldoSuficiente(precio)) {
            saldoCartera -= precio;
            System.out.println("✓ Compra realizada. Saldo restante: " + saldoCartera + "€");
        }
    }
    
    public void verBiblioteca() {
        System.out.println("\n===== BIBLIOTECA DE " + nombre.toUpperCase() + " =====");
        if (biblioteca.isEmpty()) {
            System.out.println("Tu biblioteca está vacía. ¡Compra tu primer juego!");
        } else {
            for (Compra compra : biblioteca) {
                System.out.println("- " + compra.getJuego().getTitulo() + 
                                 " (Comprado el " + compra.getFechaCompra() + ")");
            }
        }
        System.out.println("==============================\n");
    }
    
    public void verWishlist() {
        System.out.println("\n===== WISHLIST DE " + nombre.toUpperCase() + " =====");
        if (wishlist.isEmpty()) {
            System.out.println("Tu wishlist está vacía");
        } else {
            for (Juego juego : wishlist) {
                System.out.println("- " + juego.getTitulo() + " (" + juego.getPrecioBase() + "€)");
            }
        }
        System.out.println("==============================\n");
    }
    
    public String getIdCliente() {
        return idCliente;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getApellidos() {
        return apellidos;
    }
    
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public double getSaldoCartera() {
        return saldoCartera;
    }
    
    public void setSaldoCartera(double saldoCartera) {
        this.saldoCartera = saldoCartera;
    }
    
    public ArrayList<Juego> getWishlist() {
        return wishlist;
    }
    
    public ArrayList<Compra> getBiblioteca() {
        return biblioteca;
    }
    
    public boolean isNotificacionesActivas() {
        return notificacionesActivas;
    }
    
    public void setNotificacionesActivas(boolean notificacionesActivas) {
        this.notificacionesActivas = notificacionesActivas;
    }
    
    public String getGeneroFavorito() {
        return generoFavorito;
    }
    
    public void setGeneroFavorito(String generoFavorito) {
        this.generoFavorito = generoFavorito;
    }
    
    @Override
    public String toString() {
        return "Cliente: " + nombre + " " + apellidos + " (" + email + ") | Saldo: " + saldoCartera + "€";
    }
}
