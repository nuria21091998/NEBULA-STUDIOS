/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

/**
 *
 * @author Nando
 */
import java.util.ArrayList;
 
public class GestorOfertas {
    private ArrayList<Oferta> ofertasActivas;
    private ArrayList<Oferta> historialOfertas;
    
    public GestorOfertas() {
        this.ofertasActivas = new ArrayList<>();
        this.historialOfertas = new ArrayList<>();
    }
    
    public Oferta crearOferta(Juego juego, int porcentaje, String inicio, String fin, String tipo) {
        String idOferta = "OF-" + System.currentTimeMillis();
        Oferta nuevaOferta = new Oferta(idOferta, juego, porcentaje, inicio, fin, tipo);
        historialOfertas.add(nuevaOferta);
        System.out.println("✓ Oferta creada: " + nuevaOferta);
        return nuevaOferta;
    }
    
    public void activarOferta(Oferta oferta) {
        oferta.activar();
        if (!ofertasActivas.contains(oferta)) {
            ofertasActivas.add(oferta);
        }
        System.out.println("✓ Oferta activada: " + oferta.getJuego().getTitulo() + 
                         " ahora a " + oferta.getPrecioConDescuento() + "€");
    }
    
    public void desactivarOferta(Oferta oferta) {
        oferta.desactivar();
        ofertasActivas.remove(oferta);
        System.out.println("✓ Oferta desactivada para: " + oferta.getJuego().getTitulo());
    }
    
    public void verificarOfertasVencidas() {
        System.out.println("Verificando ofertas vencidas...");
        ArrayList<Oferta> ofertasADesactivar = new ArrayList<>();
        
        for (Oferta oferta : ofertasActivas) {
        }
        
        for (Oferta oferta : ofertasADesactivar) {
            desactivarOferta(oferta);
        }
    }
    
    public ArrayList<Oferta> obtenerOfertasVigentes() {
        ArrayList<Oferta> vigentes = new ArrayList<>();
        for (Oferta oferta : ofertasActivas) {
            if (oferta.estaVigente()) {
                vigentes.add(oferta);
            }
        }
        return vigentes;
    }
    
    public void aplicarOfertaFlash(ArrayList<Juego> juegos) {
        System.out.println("\n🔥 ¡OFERTA FLASH ACTIVADA! 🔥");
        for (Juego juego : juegos) {
            Oferta ofertaFlash = crearOferta(juego, 30, "HOY", "24H", "Flash");
            activarOferta(ofertaFlash);
        }
    }
    
    public void mostrarOfertasActivas() {
        System.out.println("\n===== OFERTAS ACTIVAS =====");
        if (ofertasActivas.isEmpty()) {
            System.out.println("No hay ofertas activas en este momento");
        } else {
            for (Oferta oferta : ofertasActivas) {
                System.out.println(oferta);
            }
        }
        System.out.println("===========================\n");
    }
    
    public ArrayList<Oferta> getOfertasActivas() {
        return ofertasActivas;
    }
    
    public ArrayList<Oferta> getHistorialOfertas() {
        return historialOfertas;
    }
}
