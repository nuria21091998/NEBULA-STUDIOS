/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

import java.util.ArrayList;

/**
 *
 * @author Nando
 */
public class TiendaGames {
   
    private Catalogo catalogo;
    private ArrayList<Cliente> clientes;
    private GestorOfertas gestorOfertas;
    private GestorNotificaciones gestorNotificaciones;
    private ArrayList<Compra> historialCompras;
    private GestorFicheros gestorFicheros;
    
    public TiendaGames() {
        this.catalogo = new Catalogo();
        this.clientes = new ArrayList<>();
        this.gestorOfertas = new GestorOfertas();
        this.gestorNotificaciones = new GestorNotificaciones();
        this.historialCompras = new ArrayList<>();
        this.gestorFicheros = new GestorFicheros();
    }
    
    public Cliente registrarCliente(String nombre, String apellidos, String email) {
        String idCliente = "CLI-" + System.currentTimeMillis();
        Cliente nuevoCliente = new Cliente(idCliente, nombre, apellidos, email);
        clientes.add(nuevoCliente);
        System.out.println("✓ Cliente registrado: " + nuevoCliente);
        return nuevoCliente;
    }
    
    public Cliente buscarCliente(String email) {
        for (Cliente cliente : clientes) {
            if (cliente.getEmail().equalsIgnoreCase(email)) {
                return cliente;
            }
        }
        return null;
    }
    
    public void procesarCompra(Cliente cliente, Juego juego) {
        if (!juego.tieneSuficienteStock(1)) {
            System.out.println("✗ Lo sentimos, " + juego.getTitulo() + " está agotado");
            return;
        }
        
        double precioFinal = calcularPrecioConOferta(juego);
        
        if (!cliente.tieneSaldoSuficiente(precioFinal)) {
            System.out.println("✗ Saldo insuficiente. Necesitas " + precioFinal + "€");
            System.out.println("Tu saldo actual: " + cliente.getSaldoCartera() + "€");
            return;
        }
        
        String idCompra = "COMP-" + System.currentTimeMillis();
        String fecha = "2024-03-20";
        Compra nuevaCompra = new Compra(idCompra, cliente, juego, precioFinal, fecha, "Saldo");
        
        cliente.comprarJuego(juego, precioFinal);
        juego.reducirStock(1);
        cliente.getBiblioteca().add(nuevaCompra);
        cliente.eliminarDeWishlist(juego);
        historialCompras.add(nuevaCompra);
        
        System.out.println("\n" + nuevaCompra.generarRecibo());
    }
    
    public void activarOfertaYNotificar(Juego juego, int descuento, String tipo) {
        System.out.println("\n🎯 Activando oferta para: " + juego.getTitulo());
        
        Oferta nuevaOferta = gestorOfertas.crearOferta(juego, descuento, "HOY", "SEMANA", tipo);
        gestorOfertas.activarOferta(nuevaOferta);
        
        ArrayList<Cliente> clientesInteresados = obtenerClientesConJuegoEnWishlist(juego);
        
        System.out.println("📢 Notificando a " + clientesInteresados.size() + " cliente(s)...\n");
        
        for (Cliente cliente : clientesInteresados) {
            gestorNotificaciones.notificarOfertaWishlist(cliente, juego, nuevaOferta);
        }
    }
    
    public ArrayList<Cliente> obtenerClientesConJuegoEnWishlist(Juego juego) {
        ArrayList<Cliente> resultado = new ArrayList<>();
        for (Cliente cliente : clientes) {
            if (cliente.getWishlist().contains(juego)) {
                resultado.add(cliente);
            }
        }
        return resultado;
    }
    
    private double calcularPrecioConOferta(Juego juego) {
        for (Oferta oferta : gestorOfertas.getOfertasActivas()) {
            if (oferta.getJuego().equals(juego) && oferta.estaVigente()) {
                return oferta.getPrecioConDescuento();
            }
        }
        return juego.getPrecioBase();
    }
    
    public void sincronizarOfertasYNotificaciones() {
        System.out.println("Sincronizando sistema");
        gestorOfertas.verificarOfertasVencidas();
        gestorNotificaciones.enviarNotificacionesPendientes();
        System.out.println("Sincronización completa");
    }
    
    public void generarReporteVentas() {
        System.out.println("REPORTE DE VENTAS");
        System.out.println("Total de compras: " + historialCompras.size());
        
        double totalIngresos = 0;
        for (Compra compra : historialCompras) {
            totalIngresos += compra.getPrecioCompra();
        }
        
        System.out.println("Ingresos totales: " + totalIngresos + "€");
        System.out.println("Clientes registrados: " + clientes.size());
        System.out.println("Juegos en catálogo: " + catalogo.getJuegos().size());
    }
    
    public void guardarDatos() {
        System.out.println("Guardando datos en ficheros...");
        gestorFicheros.guardarCatalogo(catalogo);
        gestorFicheros.guardarClientes(clientes);
        gestorFicheros.guardarCompras(historialCompras);
        System.out.println("Todos los datos guardados");
    }

    public void cargarDatos() {
        System.out.println("Cargando datos desde ficheros...");
        ArrayList<Juego> juegosCargados = gestorFicheros.cargarCatalogo();
        for (Juego j : juegosCargados) {
            catalogo.agregarJuego(j);
        }
        ArrayList<Cliente> clientesCargados = gestorFicheros.cargarClientes();
        clientes.addAll(clientesCargados);
        System.out.println("Datos cargados");
    }

    public void mostrarHistorialDesdefichero() {
        gestorFicheros.mostrarHistorialComprasDesdefichero();
    }

    public Juego buscarJuegoEnFichero(String idJuego) {
        return gestorFicheros.buscarJuegoPorIdEnFichero(idJuego);
    }

    public void actualizarStockEnFichero(String idJuego, int nuevoStock) {
        gestorFicheros.actualizarStockEnFichero(idJuego, nuevoStock);
    }

    public Catalogo getCatalogo() {
        return catalogo;
    }
    
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }
    
    public GestorOfertas getGestorOfertas() {
        return gestorOfertas;
    }
    
    public GestorNotificaciones getGestorNotificaciones() {
        return gestorNotificaciones;
    }
    
    public ArrayList<Compra> getHistorialCompras() {
        return historialCompras;
    }
}
