/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

/**
 *
 * @author Nando
 */
public class Oferta {
    private String idOferta;
    private Juego juego;
    private int porcentajeDescuento;
    private String fechaInicio;
    private String fechaFin;
    private String tipoOferta;
    private boolean activa;
    
    public Oferta(String idOferta, Juego juego, int porcentajeDescuento, 
                  String fechaInicio, String fechaFin, String tipoOferta) {
        this.idOferta = idOferta;
        this.juego = juego;
        this.porcentajeDescuento = porcentajeDescuento;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.tipoOferta = tipoOferta;
        this.activa = false;
    }
    
    public boolean estaVigente() {
        return activa;
    }
    
    public double aplicarDescuento() {
        return juego.getPrecioBase() * (1 - porcentajeDescuento / 100.0);
    }
    
    public double getPrecioConDescuento() {
        return aplicarDescuento();
    }
    
    public void activar() {
        this.activa = true;
    }
    
    public void desactivar() {
        this.activa = false;
    }
    
    public String getIdOferta() {
        return idOferta;
    }
    
    public Juego getJuego() {
        return juego;
    }
    
    public void setJuego(Juego juego) {
        this.juego = juego;
    }
    
    public int getPorcentajeDescuento() {
        return porcentajeDescuento;
    }
    
    public void setPorcentajeDescuento(int porcentajeDescuento) {
        this.porcentajeDescuento = porcentajeDescuento;
    }
    
    public String getFechaInicio() {
        return fechaInicio;
    }
    
    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }
    
    public String getFechaFin() {
        return fechaFin;
    }
    
    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }
    
    public String getTipoOferta() {
        return tipoOferta;
    }
    
    public void setTipoOferta(String tipoOferta) {
        this.tipoOferta = tipoOferta;
    }
    
    public boolean isActiva() {
        return activa;
    }
    
    public void setActiva(boolean activa) {
        this.activa = activa;
    }
    
    @Override
    public String toString() {
        return "Oferta " + tipoOferta + ": " + juego.getTitulo() + " -" + 
               porcentajeDescuento + "% (Precio: " + getPrecioConDescuento() + "€)";
    }
}