/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

/**
 *
 * @author Nando
 */
public class Notificacion {
    private Cliente destinatario;
    private Juego juego;
    private String mensaje;
    private String fechaEnvio;
    private boolean leida;
    private String tipoNotificacion;
    
    public Notificacion(Cliente destinatario, Juego juego, String fechaEnvio, String tipoNotificacion) {
        this.destinatario = destinatario;
        this.juego = juego;
        this.fechaEnvio = fechaEnvio;
        this.tipoNotificacion = tipoNotificacion;
        this.leida = false;
        this.mensaje = generarMensaje();
    }
    
    public String generarMensaje() {
        String mensajeGenerado = "";
        
        switch (tipoNotificacion) {
            case "Oferta":
                mensajeGenerado = "¡HEY " + destinatario.getNombre().toUpperCase() + "! " +
                                "Tu juego '" + juego.getTitulo() + "' está ahora en OFERTA. " +
                                "¡No dejes pasar esta oportunidad!";
                break;
            case "Lanzamiento":
                mensajeGenerado = "¡NOVEDAD! El juego '" + juego.getTitulo() + "' acaba de lanzarse. " +
                                "¡Cómpralo ya!";
                break;
            case "StockDisponible":
                mensajeGenerado = "¡BUENAS NOTICIAS! '" + juego.getTitulo() + "' vuelve a estar disponible " +
                                "después de estar agotado.";
                break;
            default:
                mensajeGenerado = "Tienes una nueva notificación sobre '" + juego.getTitulo() + "'";
        }
        
        return mensajeGenerado;
    }
    
    public void marcarComoLeida() {
        this.leida = true;
    }
    
    public void enviar() {
        if (destinatario.isNotificacionesActivas()) {
            System.out.println("\n📧 NOTIFICACIÓN PARA: " + destinatario.getEmail());
            System.out.println("📅 Fecha: " + fechaEnvio);
            System.out.println("📝 " + mensaje);
            System.out.println("-------------------------------------------\n");
        }
    }
    
    public Cliente getDestinatario() {
        return destinatario;
    }
    
    public void setDestinatario(Cliente destinatario) {
        this.destinatario = destinatario;
    }
    
    public Juego getJuego() {
        return juego;
    }
    
    public void setJuego(Juego juego) {
        this.juego = juego;
    }
    
    public String getMensaje() {
        return mensaje;
    }
    
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    public String getFechaEnvio() {
        return fechaEnvio;
    }
    
    public void setFechaEnvio(String fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }
    
    public boolean isLeida() {
        return leida;
    }
    
    public void setLeida(boolean leida) {
        this.leida = leida;
    }
    
    public String getTipoNotificacion() {
        return tipoNotificacion;
    }
    
    public void setTipoNotificacion(String tipoNotificacion) {
        this.tipoNotificacion = tipoNotificacion;
    }
    
    @Override
    public String toString() {
        return "[" + tipoNotificacion + "] " + mensaje + " - " + 
               (leida ? "Leída" : "No leída");
    }
}
