/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

/**
 *
 * @author Nando
 */
import java.util.ArrayList;
 
public class Catalogo {
    private ArrayList<Juego> juegos;
    
    public Catalogo() {
        this.juegos = new ArrayList<>();
    }
    
    public void agregarJuego(Juego juego) {
        juegos.add(juego);
        System.out.println("✓ Juego añadido al catálogo: " + juego.getTitulo());
    }
    
    public void eliminarJuego(String id) {
        Juego juegoAEliminar = null;
        for (Juego juego : juegos) {
            if (juego.getId().equals(id)) {
                juegoAEliminar = juego;
                break;
            }
        }
        
        if (juegoAEliminar != null) {
            juegos.remove(juegoAEliminar);
            System.out.println("✓ Juego eliminado: " + juegoAEliminar.getTitulo());
        } else {
            System.out.println("✗ No se encontró el juego con ID: " + id);
        }
    }
    
    public Juego buscarPorTitulo(String titulo) {
        for (Juego juego : juegos) {
            if (juego.getTitulo().equalsIgnoreCase(titulo)) {
                return juego;
            }
        }
        return null;
    }
    
    public ArrayList<Juego> buscarPorGenero(String genero) {
        ArrayList<Juego> resultado = new ArrayList<>();
        for (Juego juego : juegos) {
            if (juego.getGenero().equalsIgnoreCase(genero)) {
                resultado.add(juego);
            }
        }
        return resultado;
    }
    
    public ArrayList<Juego> buscarPorPlataforma(String plataforma) {
        ArrayList<Juego> resultado = new ArrayList<>();
        for (Juego juego : juegos) {
            if (juego.getPlataforma().equalsIgnoreCase(plataforma)) {
                resultado.add(juego);
            }
        }
        return resultado;
    }
    
    public ArrayList<Juego> buscarPorRangoPrecio(double min, double max) {
        ArrayList<Juego> resultado = new ArrayList<>();
        for (Juego juego : juegos) {
            if (juego.getPrecioBase() >= min && juego.getPrecioBase() <= max) {
                resultado.add(juego);
            }
        }
        return resultado;
    }
    
    public ArrayList<Juego> obtenerJuegosEnOferta() {
        System.out.println("Consultando juegos en oferta...");
        return new ArrayList<>();
    }
    
    public ArrayList<Juego> obtenerRecomendaciones(Cliente cliente) {
        ArrayList<Juego> recomendaciones = new ArrayList<>();
        String generoFav = cliente.getGeneroFavorito();
        
        if (!generoFav.isEmpty()) {
            recomendaciones = buscarPorGenero(generoFav);
            System.out.println("Recomendaciones basadas en tu género favorito: " + generoFav);
        } else {
            for (int i = 0; i < Math.min(5, juegos.size()); i++) {
                recomendaciones.add(juegos.get(i));
            }
        }
        
        return recomendaciones;
    }
    
    public void mostrarCatalogo() {
        System.out.println("\n========== CATÁLOGO DE JUEGOS ==========");
        if (juegos.isEmpty()) {
            System.out.println("El catálogo está vacío");
        } else {
            for (int i = 0; i < juegos.size(); i++) {
                System.out.println((i + 1) + ". " + juegos.get(i));
            }
        }
        System.out.println("========================================\n");
    }
    
    public void mostrarJuegosPorGenero(String genero) {
        System.out.println("\n===== JUEGOS DE " + genero.toUpperCase() + " =====");
        ArrayList<Juego> resultado = buscarPorGenero(genero);
        if (resultado.isEmpty()) {
            System.out.println("No hay juegos de este género");
        } else {
            for (Juego juego : resultado) {
                System.out.println("- " + juego);
            }
        }
        System.out.println("==============================\n");
    }
    
    public ArrayList<Juego> getJuegos() {
        return juegos;
    }
}
