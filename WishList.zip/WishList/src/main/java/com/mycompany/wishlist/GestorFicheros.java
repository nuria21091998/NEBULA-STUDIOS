package com.mycompany.wishlist;

import java.io.*;
import java.util.ArrayList;

/**
 * GestorFicheros 
 *
 * 
 */
public class GestorFicheros {

    private static final String FICHERO_CATALOGO  = "catalogo.txt";
    private static final String FICHERO_CLIENTES  = "clientes.txt";
    private static final String FICHERO_COMPRAS   = "compras.txt";
    public void guardarCatalogo(Catalogo catalogo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FICHERO_CATALOGO))) {
            for (Juego juego : catalogo.getJuegos()) {
                String linea = juego.getId()            + ";" +
                               juego.getTitulo()        + ";" +
                               juego.getDescripcion()   + ";" +
                               juego.getPrecioBase()    + ";" +
                               juego.getGenero()        + ";" +
                               juego.getPlataforma()    + ";" +
                               juego.getStock()         + ";" +
                               juego.getFechaLanzamiento() + ";" +
                               juego.getClasificacionEdad() + ";" +
                               juego.getPuntuacionMedia();
                bw.write(linea);
                bw.newLine();
            }
            System.out.println("✓ Catálogo guardado en '" + FICHERO_CATALOGO + "' (" +
                               catalogo.getJuegos().size() + " juegos).");
        } catch (IOException e) {
            System.out.println("✗ Error al guardar el catálogo: " + e.getMessage());
        }
    }

    public void guardarClientes(ArrayList<Cliente> clientes) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FICHERO_CLIENTES))) {
            for (Cliente c : clientes) {
                String linea = c.getIdCliente()                + ";" +
                               c.getNombre()                   + ";" +
                               c.getApellidos()                + ";" +
                               c.getEmail()                    + ";" +
                               c.getSaldoCartera()             + ";" +
                               c.getGeneroFavorito()           + ";" +
                               c.isNotificacionesActivas();
                bw.write(linea);
                bw.newLine();
            }
            System.out.println("✓ Clientes guardados en '" + FICHERO_CLIENTES + "' (" +
                               clientes.size() + " clientes).");
        } catch (IOException e) {
            System.out.println("✗ Error al guardar clientes: " + e.getMessage());
        }
    }

    public void guardarCompras(ArrayList<Compra> compras) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FICHERO_COMPRAS))) {
            for (Compra compra : compras) {
                String linea = compra.getIdCompra()                   + ";" +
                               compra.getCliente().getIdCliente()     + ";" +
                               compra.getJuego().getId()              + ";" +
                               compra.getPrecioCompra()               + ";" +
                               compra.getFechaCompra()                + ";" +
                               compra.getMetodoPago();
                bw.write(linea);
                bw.newLine();
            }
            System.out.println("✓ Compras guardadas en '" + FICHERO_COMPRAS + "' (" +
                               compras.size() + " compras).");
        } catch (IOException e) {
            System.out.println("✗ Error al guardar compras: " + e.getMessage());
        }
    }
   
    public ArrayList<Juego> cargarCatalogo() {
        ArrayList<Juego> juegos = new ArrayList<>();
        File fichero = new File(FICHERO_CATALOGO);
        if (!fichero.exists()) {
            System.out.println("ℹ No se encontró '" + FICHERO_CATALOGO + "'. Se iniciará catálogo vacío.");
            return juegos;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(fichero))) {
            String linea;
            int lineaNum = 0;
            while ((linea = br.readLine()) != null) {
                lineaNum++;
                linea = linea.trim();
                if (linea.isEmpty()) continue;
                String[] partes = linea.split(";");
                if (partes.length < 10) {
                    System.out.println("⚠ Línea " + lineaNum + " del catálogo ignorada (formato incorrecto).");
                    continue;
                }
                Juego j = new Juego(
                    partes[0],
                    partes[1],
                    partes[2],
                    Double.parseDouble(partes[3]),
                    partes[4],
                    partes[5],
                    Integer.parseInt(partes[6]),
                    partes[7],
                    partes[8],
                    Double.parseDouble(partes[9])
                );
                juegos.add(j);
            }
            System.out.println("✓ Catálogo cargado desde '" + FICHERO_CATALOGO + "' (" +
                               juegos.size() + " juegos).");
        } catch (IOException e) {
            System.out.println("✗ Error al cargar el catálogo: " + e.getMessage());
        }
        return juegos;
    }

    public ArrayList<Cliente> cargarClientes() {
        ArrayList<Cliente> clientes = new ArrayList<>();
        File fichero = new File(FICHERO_CLIENTES);
        if (!fichero.exists()) {
            System.out.println("ℹ No se encontró '" + FICHERO_CLIENTES + "'. Se iniciará sin clientes.");
            return clientes;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(fichero))) {
            String linea;
            int lineaNum = 0;
            while ((linea = br.readLine()) != null) {
                lineaNum++;
                linea = linea.trim();
                if (linea.isEmpty()) continue;
                String[] partes = linea.split(";");
                if (partes.length < 7) {
                    System.out.println("⚠ Línea " + lineaNum + " de clientes ignorada (formato incorrecto).");
                    continue;
                }
                Cliente c = new Cliente(partes[0], partes[1], partes[2], partes[3]);
                c.setSaldoCartera(Double.parseDouble(partes[4]));
                c.setGeneroFavorito(partes[5]);
                c.setNotificacionesActivas(Boolean.parseBoolean(partes[6]));
                clientes.add(c);
            }
            System.out.println("✓ Clientes cargados desde '" + FICHERO_CLIENTES + "' (" +
                               clientes.size() + " clientes).");
        } catch (IOException e) {
            System.out.println("✗ Error al cargar clientes: " + e.getMessage());
        }
        return clientes;
    }

    public void mostrarHistorialComprasDesdefichero() {
        File fichero = new File(FICHERO_COMPRAS);
        if (!fichero.exists()) {
            System.out.println("ℹ No se encontró '" + FICHERO_COMPRAS + "'.");
            return;
        }
        System.out.println("\n===== HISTORIAL DE COMPRAS (desde fichero) =====");
        try (BufferedReader br = new BufferedReader(new FileReader(fichero))) {
            String linea;
            int count = 0;
            while ((linea = br.readLine()) != null) {
                linea = linea.trim();
                if (linea.isEmpty()) continue;
                String[] p = linea.split(";");
                if (p.length >= 6) {
                    System.out.printf("  Compra %-12s | Cliente: %-10s | Juego: %-6s | Precio: %6s€ | Fecha: %s%n",
                        p[0], p[1], p[2], p[3], p[4]);
                    count++;
                }
            }
            System.out.println("Total: " + count + " compras.");
        } catch (IOException e) {
            System.out.println("✗ Error al leer compras: " + e.getMessage());
        }
        System.out.println("================================================\n");
    }

    public Juego buscarJuegoPorIdEnFichero(String idBuscado) {
        File fichero = new File(FICHERO_CATALOGO);
        if (!fichero.exists()) {
            System.out.println("✗ Fichero '" + FICHERO_CATALOGO + "' no encontrado.");
            return null;
        }
        System.out.println("\n🔍 Búsqueda aleatoria de juego ID='" + idBuscado + "' en fichero...");
        try (RandomAccessFile raf = new RandomAccessFile(fichero, "r")) {
            String linea;
            long posicion;
            while (raf.getFilePointer() < raf.length()) {
                posicion = raf.getFilePointer();
                linea = raf.readLine();
                if (linea == null || linea.trim().isEmpty()) continue;
                linea = new String(linea.getBytes("ISO-8859-1"), "UTF-8");
                String[] partes = linea.split(";");
                if (partes.length >= 10 && partes[0].equalsIgnoreCase(idBuscado)) {
                    System.out.println("  ✓ Encontrado en posición de byte: " + posicion);
                    return new Juego(
                        partes[0], partes[1], partes[2],
                        Double.parseDouble(partes[3]),
                        partes[4], partes[5],
                        Integer.parseInt(partes[6]),
                        partes[7], partes[8],
                        Double.parseDouble(partes[9])
                    );
                }
            }
        } catch (IOException e) {
            System.out.println("✗ Error en acceso aleatorio: " + e.getMessage());
        }
        System.out.println("  ✗ Juego con ID '" + idBuscado + "' no encontrado en fichero.");
        return null;
    }

    public void actualizarStockEnFichero(String idJuego, int nuevoStock) {
        File fichero = new File(FICHERO_CATALOGO);
        if (!fichero.exists()) {
            System.out.println("✗ Fichero '" + FICHERO_CATALOGO + "' no encontrado.");
            return;
        }

        ArrayList<String> lineas = new ArrayList<>();
        boolean encontrado = false;
        try (RandomAccessFile raf = new RandomAccessFile(fichero, "r")) {
            String linea;
            while (raf.getFilePointer() < raf.length()) {
                linea = raf.readLine();
                if (linea == null) break;
                linea = new String(linea.getBytes("ISO-8859-1"), "UTF-8");
                String[] partes = linea.split(";");
                if (partes.length >= 10 && partes[0].equalsIgnoreCase(idJuego)) {
                    partes[6] = String.valueOf(nuevoStock);
                    linea = String.join(";", partes);
                    encontrado = true;
                }
                lineas.add(linea);
            }
        } catch (IOException e) {
            System.out.println("✗ Error leyendo para actualizar: " + e.getMessage());
            return;
        }

        if (!encontrado) {
            System.out.println("✗ No se encontró el juego '" + idJuego + "' para actualizar stock.");
            return;
        }

        try (RandomAccessFile raf = new RandomAccessFile(fichero, "rw")) {
            raf.seek(0);
            raf.setLength(0);
            for (String linea : lineas) {
                raf.write((linea + "\n").getBytes("UTF-8"));
            }
            System.out.println("✓ Stock de juego '" + idJuego + "' actualizado a " +
                               nuevoStock + " en fichero (acceso aleatorio).");
        } catch (IOException e) {
            System.out.println("✗ Error escribiendo con acceso aleatorio: " + e.getMessage());
        }
    }
}
