/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

/**
 *
 * @author Nando
 */
public class Compra {
    private String idCompra;
    private Cliente cliente;
    private Juego juego;
    private double precioCompra;
    private String fechaCompra;
    private String metodoPago;
    
    public Compra(String idCompra, Cliente cliente, Juego juego, 
                  double precioCompra, String fechaCompra, String metodoPago) {
        this.idCompra = idCompra;
        this.cliente = cliente;
        this.juego = juego;
        this.precioCompra = precioCompra;
        this.fechaCompra = fechaCompra;
        this.metodoPago = metodoPago;
    }
    
    public String generarRecibo() {
        StringBuilder recibo = new StringBuilder();
        recibo.append("========== RECIBO DE COMPRA ==========\n");
        recibo.append("ID Compra: ").append(idCompra).append("\n");
        recibo.append("Cliente: ").append(cliente.getNombre()).append(" ").append(cliente.getApellidos()).append("\n");
        recibo.append("Juego: ").append(juego.getTitulo()).append("\n");
        recibo.append("Precio: ").append(precioCompra).append("€\n");
        recibo.append("Fecha: ").append(fechaCompra).append("\n");
        recibo.append("Método de pago: ").append(metodoPago).append("\n");
        recibo.append("======================================\n");
        return recibo.toString();
    }
    
    public String getIdCompra() {
        return idCompra;
    }
    
    public Cliente getCliente() {
        return cliente;
    }
    
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    public Juego getJuego() {
        return juego;
    }
    
    public void setJuego(Juego juego) {
        this.juego = juego;
    }
    
    public double getPrecioCompra() {
        return precioCompra;
    }
    
    public void setPrecioCompra(double precioCompra) {
        this.precioCompra = precioCompra;
    }
    
    public String getFechaCompra() {
        return fechaCompra;
    }
    
    public void setFechaCompra(String fechaCompra) {
        this.fechaCompra = fechaCompra;
    }
    
    public String getMetodoPago() {
        return metodoPago;
    }
    
    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }
    
    @Override
    public String toString() {
        return "Compra #" + idCompra + " - " + juego.getTitulo() + 
               " por " + precioCompra + "€ el " + fechaCompra;
    }
}
