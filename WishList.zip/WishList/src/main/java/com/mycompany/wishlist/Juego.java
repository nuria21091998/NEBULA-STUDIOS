/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

/**
 *
 * @author Nando
 */
public class Juego {
    private String id;
    private String titulo;
    private String descripcion;
    private double precioBase;
    private String genero;
    private String plataforma;
    private int stock;
    private String fechaLanzamiento;
    private String clasificacionEdad;
    private double puntuacionMedia;
    
    public Juego(String id, String titulo, String descripcion, double precioBase, 
                 String genero, String plataforma, int stock, String fechaLanzamiento, 
                 String clasificacionEdad, double puntuacionMedia) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.precioBase = precioBase;
        this.genero = genero;
        this.plataforma = plataforma;
        this.stock = stock;
        this.fechaLanzamiento = fechaLanzamiento;
        this.clasificacionEdad = clasificacionEdad;
        this.puntuacionMedia = puntuacionMedia;
    }
    
    public double calcularPrecioFinal() {
        return precioBase;
    }
    
    public boolean tieneSuficienteStock(int cantidad) {
        return stock >= cantidad;
    }
    
    public void reducirStock(int cantidad) {
        if (tieneSuficienteStock(cantidad)) {
            stock -= cantidad;
        }
    }
    
    public void aumentarStock(int cantidad) {
        stock += cantidad;
    }
    
    public String getId() {
        return id;
    }
    
    public String getTitulo() {
        return titulo;
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public double getPrecioBase() {
        return precioBase;
    }
    
    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }
    
    public String getGenero() {
        return genero;
    }
    
    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    public String getPlataforma() {
        return plataforma;
    }
    
    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }
    
    public int getStock() {
        return stock;
    }
    
    public void setStock(int stock) {
        this.stock = stock;
    }
    
    public String getFechaLanzamiento() {
        return fechaLanzamiento;
    }
    
    public void setFechaLanzamiento(String fechaLanzamiento) {
        this.fechaLanzamiento = fechaLanzamiento;
    }
    
    public String getClasificacionEdad() {
        return clasificacionEdad;
    }
    
    public void setClasificacionEdad(String clasificacionEdad) {
        this.clasificacionEdad = clasificacionEdad;
    }
    
    public double getPuntuacionMedia() {
        return puntuacionMedia;
    }
    
    public void setPuntuacionMedia(double puntuacionMedia) {
        this.puntuacionMedia = puntuacionMedia;
    }
    
    @Override
    public String toString() {
        return "Juego: " + titulo + " | Precio: " + precioBase + "€ | Género: " + genero + 
               " | Plataforma: " + plataforma + " | Stock: " + stock;
    }
}