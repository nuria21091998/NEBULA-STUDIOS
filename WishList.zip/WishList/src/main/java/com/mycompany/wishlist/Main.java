/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wishlist;

/**
 *
 * @author Nando
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("SISTEMA DE TIENDA DE VIDEOJUEGOS con Wishlist Inteligente");
        
        TiendaGames tienda = new TiendaGames();
        
        System.out.println("PASO 1: Creando catálogo de juegos...\n");
        
        Juego juego1 = new Juego("J001", "Elden Ring", "RPG de mundo abierto", 
                                 59.99, "RPG", "PC", 50, "2022-02-25", "PEGI 16", 9.5);
        
        Juego juego2 = new Juego("J002", "The Last of Us Part II", "Aventura postapocalíptica", 
                                 49.99, "Aventura", "PlayStation", 30, "2020-06-19", "PEGI 18", 9.2);
        
        Juego juego3 = new Juego("J003", "FIFA 24", "Simulador de fútbol", 
                                 69.99, "Deportes", "Multi", 100, "2023-09-29", "PEGI 3", 7.8);
        
        Juego juego4 = new Juego("J004", "Resident Evil 4 Remake", "Survival horror", 
                                 59.99, "Terror", "Multi", 40, "2023-03-24", "PEGI 18", 9.3);
        
        Juego juego5 = new Juego("J005", "Zelda: Tears of the Kingdom", "Aventura épica", 
                                 69.99, "Aventura", "Nintendo Switch", 60, "2023-05-12", "PEGI 12", 9.8);
        
        tienda.getCatalogo().agregarJuego(juego1);
        tienda.getCatalogo().agregarJuego(juego2);
        tienda.getCatalogo().agregarJuego(juego3);
        tienda.getCatalogo().agregarJuego(juego4);
        tienda.getCatalogo().agregarJuego(juego5);
        
        tienda.getCatalogo().mostrarCatalogo();
        
        System.out.println("PASO 2: Registrando clientes...");
        
        Cliente cliente1 = tienda.registrarCliente("Juan", "García López", "juan@email.com");
        Cliente cliente2 = tienda.registrarCliente("María", "Rodríguez", "maria@email.com");
        Cliente cliente3 = tienda.registrarCliente("Carlos", "Martínez", "carlos@email.com");
        
        System.out.println("PASO 3: Clientes recargando saldo...");
        
        cliente1.recargarSaldo(150.00);
        cliente2.recargarSaldo(100.00);
        cliente3.recargarSaldo(80.00);
        
        System.out.println("PASO 4: Clientes creando sus wishlists...");
        
        cliente1.agregarAWishlist(juego1);
        cliente1.agregarAWishlist(juego4);
        cliente1.setGeneroFavorito("RPG");
        
        cliente2.agregarAWishlist(juego1);
        cliente2.agregarAWishlist(juego5);
        cliente2.setGeneroFavorito("Aventura");
        
        cliente3.agregarAWishlist(juego3);
        cliente3.setGeneroFavorito("Deportes");
        
        cliente1.verWishlist();
        cliente2.verWishlist();
        cliente3.verWishlist();
        
        System.out.println("PASO 5:ACTIVANDO OFERTA ESPECIAL");        
        tienda.activarOfertaYNotificar(juego1, 25, "Semanal");
        
        System.out.println("PASO 6: Ofertas activas en la tienda...");
        tienda.getGestorOfertas().mostrarOfertasActivas();
        
        System.out.println("PASO 7: Juan realiza una compra...");
        System.out.println("Juan recibió la notificación y decide comprar Elden Ring con descuento:");
        tienda.procesarCompra(cliente1, juego1);
        
        System.out.println("PASO 8: María también realiza una compra...");
        tienda.procesarCompra(cliente2, juego1);
        
        System.out.println("PASO 9: Carlos compra FIFA 24...");
        tienda.procesarCompra(cliente3, juego3);
        
        System.out.println("PASO 10: Bibliotecas de los clientes...");
        cliente1.verBiblioteca();
        cliente2.verBiblioteca();
        cliente3.verBiblioteca();
        
        System.out.println("PASO 11: Recomendaciones personalizadas...");
        System.out.println("Recomendaciones para Juan (género favorito: RPG):");
        var recJuan = tienda.getCatalogo().obtenerRecomendaciones(cliente1);
        for (Juego j : recJuan) {
            System.out.println("- " + j.getTitulo());
        }
        
        System.out.println("PASO 12: Reporte final de ventas...");
        tienda.generarReporteVentas();
        
        System.out.println("PASO 13: OFERTA FLASH DE 24 HORAS");
        var juegosFlash = new java.util.ArrayList<Juego>();
        juegosFlash.add(juego2);
        juegosFlash.add(juego4);
        tienda.getGestorOfertas().aplicarOfertaFlash(juegosFlash);
        
        System.out.println("PASO 14: Guardando todos los datos en ficheros...");
        tienda.guardarDatos();

        System.out.println("PASO 15: Leyendo historial de compras directamente desde fichero...");
        tienda.mostrarHistorialDesdefichero();

        System.out.println("PASO 16: Búsqueda por ID usando acceso aleatorio en fichero...");
        Juego juegoEncontrado = tienda.buscarJuegoEnFichero("J003");
        if (juegoEncontrado != null) {
            System.out.println("  Juego encontrado: " + juegoEncontrado);
        }

        System.out.println("PASO 17: Actualizando stock de J001 en fichero con acceso aleatorio...");
        tienda.actualizarStockEnFichero("J001", 45);

        System.out.println("PASO 18: Verificando recuperación de datos desde fichero...");
        Juego juegoActualizado = tienda.buscarJuegoEnFichero("J001");
        if (juegoActualizado != null) {
            System.out.println("Stock actualizado de J001: " + juegoActualizado.getStock() + " unidades");
        }

        System.out.println("DEMO COMPLETADA");
    }
}
